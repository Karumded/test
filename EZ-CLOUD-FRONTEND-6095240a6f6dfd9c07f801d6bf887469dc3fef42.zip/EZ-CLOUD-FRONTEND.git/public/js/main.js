var $fnusr = '';
var $fnpwd = '';
var $load = '<button class="btn btn-info" disabled="disabled"> <i class="fa fa-circle-o-notch fa-spin fa-fw"></i> Login</button>';
var $btn = '<button type="submit" class="btn btn-info">Login</button>';

$(document).ready(function() {
    'use strict';

    $("#username").focus();

    $('#loginForm').parsley();

    $('#loginForm').submit(function(e) {
        e.preventDefault();
        $fnusr = $('#username').val().toLowerCase().replace(/ /g, '');
        var char = $fnusr.substring(0, 3);
        
        if ( char === 'cct' ){
            $fnusr = $fnusr + '@Easynet'
        }else{
            $fnusr = $fnusr + $nas;
        }
   
        $fnpwd = $('#password').val();
        
        $('#auth_user').val($fnusr);
        $('#auth_pwd').val($fnpwd);
        initialize();
    });


    if ($error !== '') {
        var html = '<div class="alert alert-dismissible alert-danger">' +
            '<button type="button" class="close" data-dismiss="alert">&times;</button>' +
            '<strong>' + $error + '</strong>' +
            '</div>';
        $('#loginError').html(html);
    }

})

function initialize() {

    var client = '&nas=' + $nas 
    + '&mac=' + $mac 
    + '&ip=' + $ip 
    + '&nas_id=' + $nas_id 
    + '&browser=' + $browser 
    + '&os=' + $os
    + '&type=' + $type; 
    var __ = 'username=' + $fnusr + '&password=' + $fnpwd + client;


    $.ajax({
            url: '/api/gateway/mikrotik',
            type: 'POST',
            dataType: 'json',
            data: __,
            beforeSend: function() {
                $('#_Async').html($load);
            },
        })
        .done(function(res) {
            
            if(typeof res.id !== 'undefined'){
                $('#_Async').html($btn);
                remove(res.id);
            }else{
                if (res.type === 'success') {
                    $('#sendin').submit();
                } else {
                    $('#_Async').html($btn);
                    var html = '<div class="alert alert-dismissible alert-danger">' +
                        '<button type="button" class="close" data-dismiss="alert">&times;</button>' +
                        '<strong> ' + res.msg + ' </strong> please try again.' +
                        '</div>';
                    $('#loginError').html(html);
                }
            }
        }); 
}


function remove(id){
    bootbox.confirm({
        message: "พบผู้ใช้ออนไลน์อยู่ ยืนยันการเข้าสู่ระบบ ?",
        buttons: {
            confirm: {
                label: 'Yes',
                className: 'btn-success'
            },
            cancel: {
                label: 'No',
                className: 'btn-danger'
            }
        },
        callback: function (result) {
            if( result ){
                $.ajax({
                    url: '/api/gateway/mikrotik',
                    type: 'PATCH',
                    dataType: 'json',
                    data:{
                        username: $fnusr,
                        password: $fnpwd,
                        id: id
                    },
                    beforeSend:function(){
                        initLoader();
                    },
                })
                .done(function(res) {
                    closeLoader();
                    if(res.type === 'success'){
                        $('#sendin').submit();
                    }
                });
            } 
        }
    });

}

function initLoader() {
    swal({
        title: "",
        text: "Processing ...",
        //showLoaderOnConfirm:true,
        showConfirmButton: false,
        imageUrl: '/img/loading.gif',
    });
}

function closeLoader() {
    swal.close();
}



