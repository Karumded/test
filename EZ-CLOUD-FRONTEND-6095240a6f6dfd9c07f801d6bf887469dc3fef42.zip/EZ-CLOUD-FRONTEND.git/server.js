import { setup } from './config/express'
setup()