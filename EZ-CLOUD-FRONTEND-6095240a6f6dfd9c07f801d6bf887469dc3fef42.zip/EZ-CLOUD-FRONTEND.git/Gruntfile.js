module.exports = function (grunt) {
    // configuration
    grunt.initConfig({
        //pass in options to plugin , reference to files etc
        concat: {
            js: {
                src: ["./public/resource/bower_components/*"],
                dest: "./public/build/script.js"
            },
            css: {
                src: ["./public/resource/*.css"],
                dest: "./public/build/styles.css"
            }
        },
        watch: {
            files: ["js/*.js"],
            tasks: ""
        },
        htmlmin: {
            // Task
            dist: {
                // Target
                options: {
                    // Target options
                    removeComments: true,
                    collapseWhitespace: true,
                    ignoreCustomFragments: [/<%[\s\S]*?%>/, /<\?[\s\S]*?\?>/, /{{[\s\S]*?}}/]
                },
                files: [
                    {
                        expand: true, // Enable dynamic expansion.
                        cwd: "./src/app/views/", // Src matches are relative to this path.
                        src: ["**/*.html"], // Actual pattern(s) to match.
                        dest: "./dist/app/views/" // Destination path prefix.
                    }
                ]
                // files: {   'dist/login/*.volt': '../app/viewsDev/login/*.volt',   cwd: 'app',
                //   src: ['../app/viewsDev/**/*.volt', '*.volt'],   dest: 'dist' }
            }
        }
    });
    // load plugins
    grunt.loadNpmTasks("grunt-contrib-concat");
    grunt.loadNpmTasks("grunt-contrib-watch");
    grunt.loadNpmTasks("grunt-contrib-htmlmin");

    // Register Tasks
    grunt.registerTask("concat-js", ["concat:js"]);
    grunt.registerTask("concat-css", ["concat:css"]);

    //
    // grunt.registerTask('sleep',function(){   console.log('Running'); });
    //
    // grunt.registerTask('all',['sleep','run']);
};