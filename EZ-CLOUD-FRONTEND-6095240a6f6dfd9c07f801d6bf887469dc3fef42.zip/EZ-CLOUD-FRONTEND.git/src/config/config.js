export default {
    port: 8080,
    secret: {
        cookie: 'T05U60Sj09nzCSM'
    },
    database: {
        radius: {
            "username": "root",
            "password": "vu:uj8]k;fN",
            "database": "radius",
            "host": "104.248.159.202",
            "dialect": "mysql",
            "path": "radius",
            "timezone": "Asia/Bangkok",
            define: {
                "timestamps": false
            }
        },
        ads: {
            "username": "root",
            "password": "vu:uj8]k;fN",
            "database": "ads",
            "host": "104.248.144.140",
            "dialect": "mysql",
            "path": "ads",
            "timezone": "Asia/Bangkok",
            operatorsAliases: false,
            define: {
                "timestamps": false
            }
        },
    }

}