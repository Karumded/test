import "@babel/polyfill";
import express from 'express';
import morgan from 'morgan';
import compression from 'compression';
import bodyParser from 'body-parser';
import cookieParser from 'cookie-parser';
import cookieEncrypter from 'cookie-encrypter';
import fs from 'fs';
import cors from 'cors';
import path from 'path';
import validator from 'express-validator';
import Sequelize from 'sequelize';
import ejs from 'ejs';
import expressLayouts from 'express-ejs-layouts';
import config from './config';

process.env.NODE_ENV = 'development';

function setupRoutes(app) {
    fs
        .readdirSync(__dirname + '/../app/routes/')
        .filter(function (file) {
            return (file.indexOf(".") !== 0) && (file !== "index.js");
        })
        .forEach(function (file) {
            const route = require(__dirname + '/../app/routes/' + file)
            route.setup(app)
        })

}

export function setup() {

    const db = {};
    const app = express();
    const PORT = config.port;

    if (process.env.NODE_ENV === 'development') {
        app.use(morgan('dev'));
    } else {
        app.use(compression());
    }

    for (var index in config.database) {
        var instance = config.database[index];
        db[index] = new Sequelize(instance.database, instance.username, instance.password, instance);

        db[index]
            .authenticate()
            .then(() => {
                console.log('Connection has been established successfully.');
            })
            .catch(err => {
                console.error('Unable to connect to the database:', err);
            });

        fs
            .readdirSync(__dirname + '/../app/models/' + instance.path + '/')
            .filter(function (file) {
                return (file.indexOf(".") !== 0) && (file !== "index.js");
            })
            .forEach(function (file) {
                var model = db[index].import (path.join(__dirname + '/../app/models/' + instance.path + '/', file));
                db[index][model.name] = model;
            });

        Object
            .keys(db[index])
            .forEach(function (modelName) {
                if ("associate" in db[index][modelName]) {
                    db[index][modelName].associate(db[database]);
                }
            });

        db[index].sequelize = db[index];
        db[index].Sequelize = db[index];

    }

    app.use(cookieParser('aASHvLUmRW74TI2'));
    app.use(cookieEncrypter('aASHvLUmRW74TI2'));
    app.use(bodyParser.urlencoded({extended: true}));
    app.use(validator());
    app.use(bodyParser.json());
    app.use(express.static('./public'));

    app.use(express.static(`${__dirname}/../../public`));

    app.set('views', `${__dirname}/../app/views`);
    app.set('layout', `${__dirname}/../app/views/layout/frontend`);
    app.set('view engine', 'html');
    app.engine('html', ejs.renderFile);
    app.use(expressLayouts);

    app.use(function (req, res, next) {
        req.db = db;
        return next();
    });

    app.use(cors());
    setupRoutes(app);

    app.use(function (req, res) {
        var json = {
            status: 'error',
            type: '404 NOT FOUND'
        };
        res
            .status(404)
            .json(json);
    });

    app.listen(config.port, () => console.log('App listening on http://localhost:' + config.port));

}