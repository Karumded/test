/**
 * @author Xeleniumz Fx
 * @version 1.0
 */

import ASSET from '../lib/asset';
import AGENT from '../lib/clientInfo';

const title = 'ezCloud Hotspot';

const getAds = async req =>{
    try {
        let bind = {};
        if (req.body.nasname !== '') {
            bind.condition = `nasname = :nasname`;
            bind.value = {
                nasname:req.body.nasname
            };
        } else {
            bind.condition = `nas_id = :roaming_nas`;
            bind.value = {
                roaming_nas: req.body.roaming_nas
            };
        }
        let nas = await req.db.ads.query(`
            SELECT
            nas.nas_id,
            nas.nasname,
            nas.shortname,
            nas.banner_id
            FROM
            nas
            where ${bind.condition}
        `, {
            replacements: bind.value,
            type: req.db.ads.QueryTypes.SELECT,
            raw: true
        });
 
        if(nas.length > 0 ){
            req.nas = nas[0];
            if(nas[0].banner_id !== null && nas[0].banner_id.length > 0){
                let banner = await req.db.ads.query(`
                    SELECT
                        banner.img1,
                        banner.img2,
                        banner.img3,
                        banner.url1,
                        banner.url2,
                        banner.url3,
                        banner.interval
                    FROM
                    banner
                    where id = :id
                `, {
                    replacements: {
                        id:nas[0].banner_id
                    },
                    type: req.db.ads.QueryTypes.SELECT,
                    raw: true
                });
                if(banner.length > 0) req.banner = banner[0];
            }
        } 
    } catch (error) {
        console.log(error);
    }
   
};
const IndexController = {

    hotspot: async(req, res,next) => {

        let val = null;
        let info = false;
        let client = false;
        req.nas = null;

        try {

            if (req.method === 'POST') {
                
                await getAds(req);
                res.clearCookie("hotspot");
                let cookieParams = {
                    httpOnly: true,
                    signed: true,
                    maxAge: 3600000 * 24
                };

                res.cookie("hotspot", req.body, cookieParams);

                if (req.body.username.includes('@')) {
                    let s = req.body.username.split('@');
                    req.body.username = s[0];
                }

                val = req.body;
                info = true;

            } else {

                if( typeof req.query.nasname !== 'undefined' || typeof req.query.roaming_nas !== 'undefined' ){
                    if (typeof req.query.nasname !== 'undefined') {
                        req.body.nasname = req.query.nasname;
                    }
                    if (typeof req.query.roaming_nas !== 'undefined') {
                        req.body.roaming_nas = req.query.roaming_nas;
                    }
                    await getAds(req);

                }else{
                    let cookie = req.signedCookies;
                    if (typeof cookie.hotspot === "undefined") {
                        res.redirect("http://google.com");
                    } else if (typeof cookie.hotspot !== "undefined") {
                        val = cookie.hotspot;
                        info = true;
                        if (typeof val.nasname !== 'undefined') {
                            req.body.nasname = val.nasname;
                        }
                        if (typeof val.roaming_nas !== 'undefined') {
                            req.body.roaming_nas = val.roaming_nas;
                        }
                        await getAds(req);
                    } 
                }
              
            }


            
            let asset = ASSET.query(req);
            if (info) {
                client = AGENT.info(req);
            }

            if(req.nas === null){
                next();
            }else{
                res.render('mikrotik/hotspot', {
                    val: val,
                    title: `${title} | log in`,
                    asset: asset,
                    nas: req.nas,
                    client: client
                });     
            }
 
        } catch (error) {
            console.log(error);
        }
       
    },


}

export default IndexController