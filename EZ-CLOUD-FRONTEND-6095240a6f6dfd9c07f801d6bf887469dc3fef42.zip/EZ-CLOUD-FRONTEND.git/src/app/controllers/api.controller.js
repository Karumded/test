/**
 * @author Xeleniumz Fx
 * @version 1.0
 */


import CLIENT from '../lib/clientInfo';
import HOTSPOT from '../lib/hotspot';
import HTTP from '../lib/http';


const ApiController = {

    mikrotik: async (req, res) => {

        if(req.method === 'POST'){
            //console.log(req.body)
            await CLIENT.fire(req);
            await CLIENT.save(req, res);
            await HOTSPOT.session(req, res);
        }else if(req.method === 'PATCH'){
            req.body.uri = 'http://rds1.easynet.co.th/v1/provider';
            req.body.method = 'PATCH';
            req.body.data = {
                id:req.body.id,
                username:req.body.username,
                password:req.body.password,
                endpoint:'disconnect'
            }
            HTTP.request(req,res);
        }

    },


}

export default ApiController