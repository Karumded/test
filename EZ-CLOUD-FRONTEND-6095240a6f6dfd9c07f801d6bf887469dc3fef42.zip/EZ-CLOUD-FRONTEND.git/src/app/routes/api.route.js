import controller from '../controllers/api.controller'

export const setup = app => {
    app
        .get('/api/gateway/mikrotik', controller.mikrotik)
        .post('/api/gateway/mikrotik', controller.mikrotik)
        .patch('/api/gateway/mikrotik', controller.mikrotik)
    //  .post('/authorize', controller.authorize) .get('/token', controller.token)
}