import controller from '../controllers/mikrotik.controller'

export function setup(app) {
    app
        .get('/', controller.hotspot)
        .post('/', controller.hotspot)
    //  .post('/authorize', controller.authorize) .get('/token', controller.token)
}

