export const isUserAuthenticated = (req, res, next) => {

    let cookie = req.signedCookies;

    if (typeof cookie.authorize !== "undefined") {

        let js = JSON.parse(cookie.authorize.acl);
        let key = req
            .path
            .replace(/[^a-zA-Z ]/g, "");

        //console.log(key,js.permission[key])

        if (js.permission[key] === 'deny') {
            res
                .status(401)
                .json({type: 'error', 'msg': 'unauthorized'});
        } else {
            return next();
        }

    } else {
        res.redirect('/');

    }

    //return next();

}