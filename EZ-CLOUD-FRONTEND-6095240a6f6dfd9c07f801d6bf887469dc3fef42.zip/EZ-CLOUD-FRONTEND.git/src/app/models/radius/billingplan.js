/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('billingplan', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    name: {
      type: DataTypes.STRING(255),
      allowNull: false
    },
    groupname: {
      type: DataTypes.STRING(128),
      allowNull: false
    },
    profile: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    amount: {
      type: DataTypes.STRING(150),
      allowNull: true
    },
    valid_for: {
      type: DataTypes.STRING(250),
      allowNull: true
    },
    price: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    IdleTimeout: {
      type: DataTypes.INTEGER(255),
      allowNull: true
    },
    simultaneous: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    redirect_url: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    bw_upload: {
      type: DataTypes.INTEGER(255),
      allowNull: true
    },
    bw_download: {
      type: DataTypes.INTEGER(255),
      allowNull: true
    },
    time_limit: {
      type: DataTypes.STRING(250),
      allowNull: true
    },
    type: {
      type: DataTypes.CHAR(10),
      allowNull: true
    },
    nas_id: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    create_at: {
      type: DataTypes.DATE,
      allowNull: true
    },
    update_at: {
      type: DataTypes.DATE,
      allowNull: true
    }
  }, {
    tableName: 'billingplan'
  });
};
