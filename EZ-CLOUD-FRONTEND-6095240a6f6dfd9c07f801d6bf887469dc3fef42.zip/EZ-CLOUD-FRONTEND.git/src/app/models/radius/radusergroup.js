/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('radusergroup', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    username: {
      type: DataTypes.STRING(64),
      allowNull: false,
      defaultValue: ''
    },
    groupname: {
      type: DataTypes.STRING(64),
      allowNull: false,
      defaultValue: ''
    },
    priority: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      defaultValue: '1'
    }
  }, {
    tableName: 'radusergroup'
  });
};
