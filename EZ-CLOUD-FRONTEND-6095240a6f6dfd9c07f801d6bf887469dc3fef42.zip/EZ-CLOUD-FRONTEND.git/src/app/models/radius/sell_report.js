/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('sell_report', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    uuid: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    username: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    password: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    name: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    groupname: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    price: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    mac: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    acctstarttime: {
      type: DataTypes.DATE,
      allowNull: true
    },
    nas_id: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    create_by: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    create_at: {
      type: DataTypes.DATE,
      allowNull: true
    }
  }, {
    tableName: 'sell_report'
  });
};
