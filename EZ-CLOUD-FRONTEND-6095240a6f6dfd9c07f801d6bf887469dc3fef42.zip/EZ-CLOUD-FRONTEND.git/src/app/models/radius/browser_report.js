/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('browser_report', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    date: {
      type: DataTypes.DATEONLY,
      allowNull: false
    },
    chrome: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    firefox: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    opera: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    explorer: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    safari: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    android: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    unknow: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    nas_id: {
      type: DataTypes.INTEGER(150),
      allowNull: true
    }
  }, {
    tableName: 'browser_report'
  });
};
