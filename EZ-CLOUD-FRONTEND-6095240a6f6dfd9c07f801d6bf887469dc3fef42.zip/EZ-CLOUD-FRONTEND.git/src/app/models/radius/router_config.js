/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('router_config', {
    router_id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    user_id: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    router_ip: {
      type: DataTypes.STRING(300),
      allowNull: false
    },
    router_user: {
      type: DataTypes.STRING(300),
      allowNull: false
    },
    router_pass: {
      type: DataTypes.STRING(300),
      allowNull: false
    },
    router_port: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    }
  }, {
    tableName: 'router_config'
  });
};
