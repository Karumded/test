/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('os_report', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    date: {
      type: DataTypes.DATEONLY,
      allowNull: false
    },
    windows: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    windows_phone: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    android: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    iOS: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    macOS: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    ubuntu: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    debian: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    gentoo: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    linux: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    blackberry: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    unknow: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    nas_id: {
      type: DataTypes.INTEGER(150),
      allowNull: true
    }
  }, {
    tableName: 'os_report'
  });
};
