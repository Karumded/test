/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('radacct', {
    radacctid: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    acctsessionid: {
      type: DataTypes.STRING(64),
      allowNull: false,
      defaultValue: ''
    },
    acctuniqueid: {
      type: DataTypes.STRING(32),
      allowNull: false,
      defaultValue: '',
      unique: true
    },
    username: {
      type: DataTypes.STRING(64),
      allowNull: false,
      defaultValue: ''
    },
    groupname: {
      type: DataTypes.STRING(64),
      allowNull: false,
      defaultValue: ''
    },
    realm: {
      type: DataTypes.STRING(64),
      allowNull: true,
      defaultValue: ''
    },
    nasipaddress: {
      type: DataTypes.STRING(15),
      allowNull: false,
      defaultValue: ''
    },
    nasportid: {
      type: DataTypes.STRING(15),
      allowNull: true
    },
    nasporttype: {
      type: DataTypes.STRING(32),
      allowNull: true
    },
    acctstarttime: {
      type: DataTypes.DATE,
      allowNull: true
    },
    acctstoptime: {
      type: DataTypes.DATE,
      allowNull: true
    },
    acctsessiontime: {
      type: DataTypes.INTEGER(12),
      allowNull: true
    },
    acctauthentic: {
      type: DataTypes.STRING(32),
      allowNull: true
    },
    connectinfo_start: {
      type: DataTypes.STRING(50),
      allowNull: true
    },
    connectinfo_stop: {
      type: DataTypes.STRING(50),
      allowNull: true
    },
    acctinputoctets: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    acctoutputoctets: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    calledstationid: {
      type: DataTypes.STRING(50),
      allowNull: false,
      defaultValue: ''
    },
    callingstationid: {
      type: DataTypes.STRING(50),
      allowNull: false,
      defaultValue: ''
    },
    acctterminatecause: {
      type: DataTypes.STRING(32),
      allowNull: false,
      defaultValue: ''
    },
    servicetype: {
      type: DataTypes.STRING(64),
      allowNull: true
    },
    framedprotocol: {
      type: DataTypes.STRING(32),
      allowNull: true
    },
    framedipaddress: {
      type: DataTypes.STRING(15),
      allowNull: false,
      defaultValue: ''
    },
    acctstartdelay: {
      type: DataTypes.INTEGER(12),
      allowNull: true
    },
    acctstopdelay: {
      type: DataTypes.INTEGER(12),
      allowNull: true
    },
    xascendsessionsvrkey: {
      type: DataTypes.STRING(10),
      allowNull: true
    }
  }, {
    tableName: 'radacct'
  });
};
