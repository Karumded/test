/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('radpostauth', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    username: {
      type: DataTypes.STRING(64),
      allowNull: false,
      defaultValue: ''
    },
    pass: {
      type: DataTypes.STRING(150),
      allowNull: false,
      defaultValue: ''
    },
    reply: {
      type: DataTypes.STRING(250),
      allowNull: false,
      defaultValue: ''
    },
    authdate: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: sequelize.literal('CURRENT_TIMESTAMP')
    },
    nas: {
      type: DataTypes.STRING(255),
      allowNull: true
    }
  }, {
    tableName: 'radpostauth'
  });
};
