/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('nas', {
    id: {
      type: DataTypes.INTEGER(10),
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    nasname: {
      type: DataTypes.STRING(128),
      allowNull: false
    },
    shortname: {
      type: DataTypes.STRING(128),
      allowNull: true
    },
    type: {
      type: DataTypes.STRING(30),
      allowNull: true,
      defaultValue: 'other'
    },
    ports: {
      type: DataTypes.INTEGER(5),
      allowNull: true
    },
    secret: {
      type: DataTypes.STRING(60),
      allowNull: false,
      defaultValue: 'secret'
    },
    community: {
      type: DataTypes.STRING(50),
      allowNull: true
    },
    reg_profile: {
      type: DataTypes.STRING(150),
      allowNull: true
    },
    banner: {
      type: DataTypes.STRING(150),
      allowNull: true
    },
    vpn_user: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    vpn_pwd: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    vpn_ip: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    roaming_nas: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    gateway: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    zone_id: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    customer_id: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    announce: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    lat: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    lng: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    online: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    mobile: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    desktop: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    create_at: {
      type: DataTypes.DATE,
      allowNull: true
    },
    update_at: {
      type: DataTypes.DATE,
      allowNull: true
    }
  }, {
    tableName: 'nas'
  });
};
