/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('client_detail', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    username: {
      type: DataTypes.STRING(250),
      allowNull: true
    },
    framedipaddress: {
      type: DataTypes.STRING(150),
      allowNull: false
    },
    browser: {
      type: DataTypes.STRING(150),
      allowNull: false
    },
    os: {
      type: DataTypes.STRING(150),
      allowNull: false
    },
    active: {
      type: DataTypes.STRING(128),
      allowNull: true
    },
    type: {
      type: DataTypes.STRING(128),
      allowNull: false
    },
    nas_id: {
      type: DataTypes.INTEGER(255),
      allowNull: true
    }
  }, {
    tableName: 'client_detail'
  });
};
