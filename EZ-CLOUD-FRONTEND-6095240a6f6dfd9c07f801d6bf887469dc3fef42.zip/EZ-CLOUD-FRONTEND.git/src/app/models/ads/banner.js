/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('banner', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    name: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    img1: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    img2: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    img3: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    url1: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    url2: {
      type: DataTypes.STRING(255),
      allowNull: false
    },
    url3: {
      type: DataTypes.STRING(255),
      allowNull: false
    },
    interval: {
      type: DataTypes.STRING(255),
      allowNull: false
    },
    createAt: {
      type: DataTypes.DATE,
      allowNull: false
    },
    updateAt: {
      type: DataTypes.DATE,
      allowNull: true
    }
  }, {
    tableName: 'banner'
  });
};
