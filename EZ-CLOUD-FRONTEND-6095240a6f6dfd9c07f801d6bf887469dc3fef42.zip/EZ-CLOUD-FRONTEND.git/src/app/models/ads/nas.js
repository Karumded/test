/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('nas', {
    id: {
      type: DataTypes.INTEGER(10),
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    nas_id: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    nasname: {
      type: DataTypes.STRING(128),
      allowNull: false
    },
    shortname: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    banner_id: {
      type: DataTypes.STRING(128),
      allowNull: true
    },
    roaming_nas: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    createAt: {
      type: DataTypes.DATE,
      allowNull: true
    },
    updateAt: {
      type: DataTypes.DATE,
      allowNull: true
    }
  }, {
    tableName: 'nas'
  });
};
